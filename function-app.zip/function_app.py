import azure.functions as func
import logging

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="STORAGE_ACCOUNT_CONNECTION_STRING")
def storageQueueCopyBlob(msg: func.QueueMessage):
    logging.info('Python queue trigger function processed a queue item: %s',
                 msg.get_body().decode('utf-8'))
