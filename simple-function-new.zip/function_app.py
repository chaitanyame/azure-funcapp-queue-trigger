import azure.functions as func
import logging

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="AzureWebJobsStorage")
def QueueTriggerFunction(msg: func.QueueMessage):
    """
    Simple function that just logs the received queue message
    """
    logging.info('Python queue trigger function processed a queue item')
    
    # Get the message content
    message_content = msg.get_body().decode('utf-8')
    
    # Log the message content
    logging.info(f'Message received: {message_content}')
    
    # Print to console as well (will show in Application Insights)
    print(f"Queue message processed: {message_content}")
