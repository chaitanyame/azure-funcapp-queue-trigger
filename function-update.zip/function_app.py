import azure.functions as func
import logging

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="STORAGE_ACCOUNT_CONNECTION_STRING")
@app.blob_input(arg_name="inputblob", path="helloworld/{msg}",
                connection="STORAGE_ACCOUNT_CONNECTION_STRING")
@app.blob_output(arg_name="outputblob", path="helloworld/{msg}-copy",
                 connection="STORAGE_ACCOUNT_CONNECTION_STRING")
def storageQueueCopyBlob(msg: func.QueueMessage, inputblob: func.InputStream, outputblob: func.Out[bytes]):
    try:
        # Log the raw message to understand the format
        logging.info('Raw message type: %s', type(msg.get_body()))
        logging.info('Raw message content: %s', repr(msg.get_body()))
        
        # Get message as string - try different approaches
        try:
            if hasattr(msg, 'get_body'):
                raw_body = msg.get_body()
                if isinstance(raw_body, bytes):
                    message_content = raw_body.decode('utf-8')
                else:
                    message_content = str(raw_body)
            else:
                message_content = str(msg)
                
            logging.info('Decoded message: %s', message_content)
            
        except Exception as decode_error:
            logging.error('Message decoding failed: %s', str(decode_error))
            raise
        
        # Read the input blob
        blob_data = inputblob.read()
        logging.info('Successfully read %d bytes from input blob', len(blob_data))
        
        # Write to the output blob
        outputblob.set(blob_data)
        logging.info('Successfully wrote blob data to output')
        
        logging.info('Function completed successfully')
        
    except Exception as e:
        logging.error('Function failed with error: %s', str(e))
        logging.error('Error type: %s', type(e).__name__)
        import traceback
        logging.error('Traceback: %s', traceback.format_exc())
        raise
