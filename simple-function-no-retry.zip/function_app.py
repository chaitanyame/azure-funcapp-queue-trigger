import azure.functions as func
import logging
import base64

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="AzureWebJobsStorage")
def QueueTriggerFunction(msg: func.QueueMessage):
    """
    Simple function that just logs the received queue message
    """
    logging.info('Python queue trigger function processed a queue item')
    
    try:
        # Get the raw message content
        raw_content = msg.get_body()
        
        # Try to decode as string first
        try:
            message_content = raw_content.decode('utf-8')
            logging.info(f'Message received (direct): {message_content}')
        except UnicodeDecodeError:
            # If direct decode fails, try base64 decode
            try:
                decoded_bytes = base64.b64decode(raw_content)
                message_content = decoded_bytes.decode('utf-8')
                logging.info(f'Message received (base64): {message_content}')
            except Exception as decode_error:
                # If all else fails, just log the raw bytes
                message_content = str(raw_content)
                logging.info(f'Message received (raw): {message_content}')
        
        # Print to console as well (will show in Application Insights)
        print(f"Queue message processed: {message_content}")
        
    except Exception as e:
        logging.error(f'Error processing message: {e}')
        print(f"Error processing queue message: {e}")
        # Don't re-raise to avoid poison queue
        logging.info('Message processing completed despite error')
