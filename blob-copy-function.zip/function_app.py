import azure.functions as func
import logging
import os
import json
from datetime import datetime
from azure.storage.blob import BlobServiceClient

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="AzureWebJobsStorage")
def QueueTriggerFunction(msg: func.QueueMessage):
    """
    Function that processes queue messages and copies blobs with timestamp
    """
    logging.info('Python queue trigger function processed a queue item')
    
    try:
        # Since messageEncoding is "none", get message as string directly
        message_content = msg.get_body().decode('utf-8')
        
        # Log the message content
        logging.info(f'Message received: {message_content}')
        
        # Try to parse as JSON to get blob name, otherwise use the message as blob name
        try:
            message_data = json.loads(message_content)
            blob_name = message_data.get('blobName', message_content.strip())
        except (json.JSONDecodeError, TypeError):
            blob_name = message_content.strip()
        
        logging.info(f'Processing blob: {blob_name}')
        
        # Get connection string from environment
        connection_string = os.environ["AzureWebJobsStorage"]
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        
        container_name = "helloworld"
        
        # Create timestamp for the copy
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        
        # Create the new blob name with copy_time_message format
        name_parts = os.path.splitext(blob_name)
        if name_parts[1]:  # Has extension
            copy_blob_name = f"copy_{timestamp}_{name_parts[0]}{name_parts[1]}"
        else:  # No extension
            copy_blob_name = f"copy_{timestamp}_{blob_name}"
        
        logging.info(f'Copying {blob_name} to {copy_blob_name}')
        
        # Get source blob client
        source_blob_client = blob_service_client.get_blob_client(
            container=container_name,
            blob=blob_name
        )
        
        # Check if source blob exists
        if source_blob_client.exists():
            logging.info('Source blob exists, proceeding with copy')
            
            # Get destination blob client
            dest_blob_client = blob_service_client.get_blob_client(
                container=container_name,
                blob=copy_blob_name
            )
            
            # Copy the blob
            copy_source = source_blob_client.url
            dest_blob_client.start_copy_from_url(copy_source)
            
            logging.info(f'Successfully initiated blob copy from {blob_name} to {copy_blob_name}')
            print(f"Blob copied: {blob_name} -> {copy_blob_name}")
            
        else:
            error_msg = f"Source blob '{blob_name}' does not exist in container '{container_name}'"
            logging.warning(error_msg)
            print(f"Warning: {error_msg}")
        
    except Exception as e:
        logging.error(f'Error processing message: {e}')
        print(f"Error processing queue message: {e}")
        # Don't re-raise to prevent retries
        logging.info('Message processing completed despite error')
