import azure.functions as func
import logging
import os
import json
from azure.storage.blob import BlobServiceClient

app = func.FunctionApp()

@app.queue_trigger(arg_name="msg", queue_name="copyblobqueue",
                   connection="STORAGE_ACCOUNT_CONNECTION_STRING")
def storageQueueCopyBlob(msg: str):
    try:
        logging.info('Python queue trigger function processed a queue item: %s', msg)

        # The 'msg' is now a string. It might be a plain string or a JSON string.
        try:
            # Clean up the message string before parsing
            cleaned_msg = msg.strip().strip('''"''').strip("'")
            message_data = json.loads(cleaned_msg)
            blob_name = message_data.get('blobName', cleaned_msg)
            logging.info('Parsed JSON - blob name: %s', blob_name)
        except (json.JSONDecodeError, TypeError):
            blob_name = msg.strip().strip('''"''').strip("'")
            logging.info('Using plain string - blob name: %s', blob_name)

        # Use Azure Storage SDK to copy blob
        # Get connection string from environment
        connection_string = os.environ["STORAGE_ACCOUNT_CONNECTION_STRING"]
        logging.info('Connection string exists: %s', bool(connection_string))

        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        container_name = "helloworld"
        source_blob_name = blob_name
        dest_blob_name = f"{os.path.splitext(blob_name)[0]}-copy{os.path.splitext(blob_name)[1]}"

        logging.info('About to check blob: %s in container: %s', source_blob_name, container_name)

        # Get source blob client
        source_blob_client = blob_service_client.get_blob_client(
            container=container_name,
            blob=source_blob_name
        )

        # Check if source blob exists first
        if source_blob_client.exists():
            logging.info('Source blob exists, proceeding with copy')

            # Get destination blob client
            dest_blob_client = blob_service_client.get_blob_client(
                container=container_name,
                blob=dest_blob_name
            )

            # Copy the blob using copy_from_url
            copy_source = source_blob_client.url
            logging.info('Starting copy from: %s', copy_source)

            dest_blob_client.start_copy_from_url(copy_source)

            logging.info('Successfully initiated blob copy from %s to %s', source_blob_name, dest_blob_name)
        else:
            raise Exception(f"Source blob '{source_blob_name}' does not exist in container '{container_name}'")

    except Exception as e:
        logging.error('Error processing queue message: %s', str(e))
        raise
